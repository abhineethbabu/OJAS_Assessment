const mongoose = require('mongoose');

const dataSchema = new mongoose.Schema({
    id: { type: Number, unique: true, required: true },
    Name: { type: String, required: true },
    Age: { type: Number, required: true },
    Place: { type: String, required: true },
    checksum: { type: Number, required: true } // Added checksum field
});

const Data = mongoose.model('Data', dataSchema);

module.exports = Data;
