// server.js
const express = require('express');
const multer = require('multer');
const csvParser = require('csv-parser');
const fs = require('fs');
const mongoose = require('mongoose');
const Data = require('./models/DataModels');

const app = express();
const port = 3000;

mongoose.connect("mongodb+srv://abhi:<abhi>@cluster0.uthoxt0.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("MongoDB connected");
}).catch((err) => {
    console.error("MongoDB connection error:", err);
});

app.use(express.static('public'));

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const upload = multer({ storage: storage });

function computeChecksum(record) {
    const str = `${record.id}${record.Name}${record.Age}${record.Place}`;
    let checksum = 0;
    for (let i = 0; i < str.length; i++) {
        checksum += str.charCodeAt(i);
    }
    return checksum;
}

app.post('/upload', upload.single('csvFile'), async (req, res) => {
    try {
        const results = [];
        fs.createReadStream(req.file.path)
            .pipe(csvParser())
            .on('data', (data) => {
                const checksum = computeChecksum(data);
                data.checksum = checksum;
                results.push(data);
            })
            .on('end', async () => {
                for (const record of results) {
                    const existingRecord = await Data.findOne({ id: record.id });
                    if (existingRecord) {
                        if (existingRecord.checksum !== record.checksum) {
                            await Data.updateOne({ id: record.id }, record);
                        }
                    } else {
                        const newRecord = new Data(record);
                        await newRecord.save();
                    }
                }
                res.send('CSV file uploaded and data processed successfully');
            });
    } catch (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
    }
});

app.listen(port, () => {
    console.log(`Live on Port = ${port}`);
});
